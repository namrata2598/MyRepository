package com.example.SmallWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmallWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
