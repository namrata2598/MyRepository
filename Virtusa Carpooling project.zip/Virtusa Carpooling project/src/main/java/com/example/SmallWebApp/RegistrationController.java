package com.example.SmallWebApp;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.SmallWebApp.Dao.UserRepo;

@Controller
public class RegistrationController {

	@Autowired
	UserRepo repo;
	
	@RequestMapping("/regform")
	public String register()
	{
		return "registration";
	}
	
	/*@RequestMapping("/userDetails")
	public ModelAndView userInfo(UserRegistration reg)
	{
		ModelMap model=new ModelMap();
		
		model.addAttribute("name", reg.getUname());
		model.addAttribute("email", reg.getEmailId());
		//model.addAttribute("passoword", reg.getPassword());
		model.addAttribute("gender", reg.getGender()==Integer.parseInt("1")? "Male" : "Female");
		model.addAttribute("hobby", reg.getHobby());
		
		ModelAndView mv=new ModelAndView("user-details");
		mv.addObject("regObj", model);
		return mv;
	}*/
	
	@RequestMapping("/login")
	public ModelAndView login() {
	  ModelAndView model = new ModelAndView();
	  
	  model.setViewName("/login");
	  return model;
		//return "registration";
	 }
	
	@RequestMapping("/operation")
	public String operation() {
		//
		return "operation";
	}
	
	
	@RequestMapping("/userDetails")
	public String userInfo(UserRegistration reg)
	{
		repo.save(reg);
		return "login";
	}
	
	/*@Autowired
    public RegisterController(BCryptPasswordEncoder bCryptPasswordEncoder, UserService userService, EmailService emailService) {
      
      this.bCryptPasswordEncoder = bCryptPasswordEncoder;
      this.userService = userService;
      this.emailService = emailService;
    }
	@RequestMapping(value="/register", method = RequestMethod.GET)
	public ModelAndView showRegistrationPage(ModelAndView modelAndView, UserRegistration user){
		modelAndView.addObject("user", user);
		modelAndView.setViewName("register");
		return modelAndView;
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView processRegistrationForm(ModelAndView modelAndView, @Valid UserRegistration user, BindingResult bindingResult, HttpServletRequest request) {
				
		// Lookup user in database by e-mail
		UserRegistration userExists = userService.findByEmail(user.getEmailId());
		
		System.out.println(userExists);
		
		if (userExists != null) {
			modelAndView.addObject("alreadyRegisteredMessage", "Oops!  There is already a user registered with the email provided.");
			modelAndView.setViewName("register");
			bindingResult.reject("email");
		}
			
		if (bindingResult.hasErrors()) { 
			modelAndView.setViewName("register");		
		} else { // new user so we create user and send confirmation e-mail
					
			// Disable user until they click on confirmation link in email
		    user.setEnabled(false);
		      
		    // Generate random 36-character string token for confirmation link
		    user.setConfirmationToken(UId.randomUUID().toString());
		        
		    userService.saveUser(user);
				
			String appUrl = request.getScheme() + "://" + request.getServerName();
			
			SimpleMailMessage registrationEmail = new SimpleMailMessage();
			registrationEmail.setTo(user.getEmailId());
			registrationEmail.setSubject("Registration Confirmation");
			registrationEmail.setText("To confirm your e-mail address, please click the link below:\n"
					+ appUrl + "/confirm?token=" + user.getConfirmationToken());
			registrationEmail.setFrom("noreply@domain.com");
			
			emailService.sendEmail(registrationEmail);
			
			modelAndView.addObject("confirmationMessage", "A confirmation e-mail has been sent to " + user.getEmailId());
			modelAndView.setViewName("register");
		}
			
		return modelAndView;
	}*/
	
	
	/*@RequestMapping("/operation")
	public String operation(long Uid, String ddlflag)
	{
		if(ddlflag.equals("select"))
		{
			
			/*UserRegistration reg=repo.findById(UID).orElse(new UserRegistration());
			return selectRecords(reg);---------------------
			System.out.println(ddlflag);
			}
		else if(ddlflag.equals("delete")) {
			System.out.println(ddlflag);
		}
		else if(ddlflag.equals("update"))
		{
			System.out.println(ddlflag);
		}else {
			
		}
		
		return "operation";
	}
	
	/*public ModelAndView selectRecords(UserRegistration reg) {

		ModelMap model=new ModelMap();
		
		model.put("name", reg.getUname());
		model.put("email", reg.getEmailId());
		//model.addAttribute("passoword", reg.getPassword());
		model.put("gender", reg.getGender()==Integer.parseInt("1")? "Male" : "Female");
		
		
		ModelAndView mv=new ModelAndView("user-details");
		mv.addObject("regObj", model);
		return mv;
	}*/
}
